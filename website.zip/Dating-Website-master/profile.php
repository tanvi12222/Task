﻿<!DOCTYPE html>
<html>

<head>
    <link href="profile.css" rel="stylesheet">
</head>

<body>
<?php include'header.php'?>
    
    


    <div class="jpg1">
        <a href="details.php"><img src="images/b1.jpg" style="width:300px;height:300px;margin-left:-60px;"></a>
        <a href="details.php"><img src="images/b2.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b3.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b4.jpg" style="width:300px;height:300px;margin-left:-60px;"></a>
        <a href="details.php"><img src="images/b5.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b2.jpg" style="width:300px;height:300px;margin-left:20px;"><</a>
        <a href="details.php"><img src="images/b1.jpg" style="width:300px;height:300px;margin-left:-60px;"></a>
        <a href="details.php"><img src="images/b2.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b3.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b4.jpg" style="width:300px;height:300px;margin-left:-60px;"></a>
        <a href="details.php"><img src="images/b5.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b2.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b1.jpg" style="width:300px;height:300px;margin-left:-60px;"></a>
        <a href="details.php"><img src="images/b2.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b3.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b4.jpg" style="width:300px;height:300px;margin-left:-60px;"></a>
        <a href="details.php"><img src="images/b5.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
        <a href="details.php"><img src="images/b2.jpg" style="width:300px;height:300px;margin-left:20px;"></a>
    </div>


    
        <div class="line1">
            <a href="">DON'T STAY ALONE!</br></a>
            <p> When we truly realize that we are all alone is when we need others the most.<br>
                Don't feel alone, because there is always someone out there who loves you more than you can imagine.<br>
                Without great solitude no serious work is possible. If you are afraid of being lonely, don't try to be right."</p>
            <div>
                <div class="line2">
                    <a href="">FIND YOUR LOVE</a>
                    <P>"It's so easy to fall in love but hard to find someone who will catch you."<br>
                        "Sometimes the one thing you are looking for is the one thing you can't see." <br>
                        "Nothing compares with the finding of true love; <br>because once you do your heart is complete."
                        <br>"It is never too late to fall in love."</P>
</div>
                        <div class="line3">
                            <a href="">REGISTER FOR FREE!!!!</a>
                            <p>
                                Pay securely at millions of stores and send money quickly to anyone’s PayPal <br>
                                email address or mobile number.
                                ... It’s free - sign up for a PayPal account,<br> and shop without transaction fees*,<br>
                                no matter how you choose to pay. ... Securely accept<br> credit and Visa Debit card payments without a ...
                            </P>
                            
<div>
</div>

<div style="position:absolute; width:98%; left:10px; margin:5px; margin-left:5px ">
<?php  include 'footer.php'?>
</div>

</body>

</html>